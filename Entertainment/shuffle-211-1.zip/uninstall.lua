-- Instinctiv Shuffle uninstall script
-- Created by slava @ 01/21/08

installer.RemovePath("~/Library/Instinctiv")
installer.RemovePath("/Applications/Shuffle.app")
installer.RemovePath("/Library/MobileSubstrate/DynamicLibraries/libshuffle.dylib")
installer.RemovePath("/Library/MobileSubstrate/DynamicLibraries/libshuffle.plist")

return true
