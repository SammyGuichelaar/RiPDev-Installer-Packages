-- Instinctiv Shuffle uninstall script
-- Created by slava @ 01/21/08

installer.RemovePath("~/Library/Instinctiv")
installer.RemovePath("/Applications/Shuffle.app")
installer.CopyPath("/Library/MobileSubstrate/DynamicLibraries/libshuffle.dylib")
installer.CopyPath("/Library/MobileSubstrate/DynamicLibraries/libshuffle.plist")

return true
