-- Instinctiv Shuffle install script
-- Created by slava @ 01/21/08

installer.CopyPath("Instinctiv", "~/Library/Instinctiv")
installer.CopyPath("Shuffle.app", "/Applications/Shuffle.app")
installer.CopyPath("libshuffle.dylib", "/Library/MobileSubstrate/DynamicLibraries/libshuffle.dylib")
installer.CopyPath("libshuffle.plist", "/Library/MobileSubstrate/DynamicLibraries/libshuffle.plist")

if (not installer.ExistsPath("/usr/local/lib/libstdc++.6.0.4.dylib")) then
	installer.CopyPath("libstdc++.6.0.4.dylib", "/usr/local/lib/libstdc++.6.0.4.dylib")
	installer.LinkPath("/usr/local/lib/libstdc++.6.0.4.dylib", "/usr/local/lib/libstdc++.6.dylib")
end

installer.ChangeOwnerGroup("/var/mobile/Library/Instinctiv", "mobile", "mobile")
installer.ChangeOwnerGroup("/Applications/Shuffle.app/prerun", "mobile", "mobile")
installer.ChangeMode("/Applications/Shuffle.app/prerun", "6755")
os.execute("/Applications/Shuffle.app/prerun")

return true
