-- i2Reader install script
-- ©2008, Ripdev - http://ripdev.com

installer.SetStatus("Installing App…")
installer.CopyPath("i2Reader.app", "/Applications/i2Reader.app")
installer.SetStatus("Installing Components…")
installer.CopyPath("i2Reader.bundle", "~/Library/RiPDev/Packages/i2Reader.bundle")
installer.CopyPath("i2Reader", "~/Library/i2Reader")
installer.CopyPath("FSO_i2Reader.png", "/System/Library/CoreServices/SpringBoard.app/FSO_i2Reader.png")
installer.CopyPath("Default_i2Reader.png", "/System/Library/CoreServices/SpringBoard.app/Default_i2Reader.png")
installer.CopyPath("Media", "~/Media")

installer.SetStatus("Fixing Permissions…")
installer.ChangeOwnerGroup("/var/mobile/Library/i2Reader", "mobile", "mobile")
installer.ChangeOwnerGroup("/var/mobile/Media/BookLibrary", "mobile", "mobile")

return true
