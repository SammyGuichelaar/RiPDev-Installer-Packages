-- i2Reader install script
-- ©2008, Ripdev - http://ripdev.com

installer.CopyPath("i2Reader.app", "/Applications/i2Reader.app")
installer.CopyPath("i2Reader.bundle", "~/Library/RiPDev/Packages/i2Reader.bundle")
installer.CopyPath("i2Reader", "~/Library/i2Reader")
installer.CopyPath("FSO_i2Reader.png", "/System/Library/CoreServices/SpringBoard.app/FSO_i2Reader.png")
installer.CopyPath("Default_i2Reader.png", "/System/Library/CoreServices/SpringBoard.app/Default_i2Reader.png")
if not installer.PathExists("~/Media/BookLibrary") then
	installer.CopyPath("BookLibrary", "~/Media/BookLibrary")
end
installer.ChangeOwnerGroup("/var/mobile/Library/i2Reader", "mobile", "mobile")
installer.ChangeOwnerGroup("/var/mobile/Media/BookLibrary", "mobile", "mobile")

return true
