-- i2Reader uninstall script
-- ©2008, Ripdev - http://ripdev.com

installer.RemovePath("/Applications/i2Reader.app")
installer.RemovePath("~/Library/RiPDev/Packages/i2Reader.bundle")
installer.RemovePath("~/Library/i2Reader")
installer.RemovePath("/System/Library/CoreServices/SpringBoard.app/FSO_i2Reader.png")
installer.RemovePath("/System/Library/CoreServices/SpringBoard.app/Default_i2Reader.png")

return true
