-- i2Reader uninstall script
-- ©2008-2009, Ripdev - http://ripdev.com

installer.RemovePath("/Applications/i2ReaderPro.app")
installer.RemovePath("/System/Library/CoreServices/SpringBoard.app/FSO_i2Reader.png")
installer.RemovePath("/System/Library/CoreServices/SpringBoard.app/Default_i2Reader.png")

return true
