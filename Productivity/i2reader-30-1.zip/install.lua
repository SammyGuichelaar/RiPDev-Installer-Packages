-- i2Reader install script
-- ©2008-2009, Ripdev - http://ripdev.com

installer.RemovePath("/Applications/i2Reader.app")
installer.CopyPath("i2ReaderPro.app", "/Applications/i2ReaderPro.app")
installer.CopyPath("FSO_i2Reader.png", "/System/Library/CoreServices/SpringBoard.app/FSO_i2Reader.png")
installer.CopyPath("Default_i2Reader.png", "/System/Library/CoreServices/SpringBoard.app/Default_i2Reader.png")

return true
