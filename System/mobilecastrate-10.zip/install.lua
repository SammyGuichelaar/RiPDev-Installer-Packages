-- Controls installation of MobileCastrate
-- Copyright ©2008, Ripdev
-- Hello Jay! :)

if installer.DeviceRootLocked() then
	return "Unfortunately you cannot install PseudoSubstrate as the device root is not unlocked. Sorry!"
end

if not installer.ExistsPath("/Library/MobileSubstrate/MobileSubstrate.dylib") then
	installer.CopyPath("MobileCastrate.men", "/var/MobileEnhancer/MobileCastrate.men")
	
	installer.CopyPath("libcastrate.dylib", "/var/Ripdev/libexec/libcastrate.dylib")

	if not installer.ExistsPath("/usr/lib/libsubstrate.dylib") then
		installer.LinkPath("/var/Ripdev/libexec/libcastrate.dylib", "/usr/lib/libsubstrate.dylib")
	end
end

return true
