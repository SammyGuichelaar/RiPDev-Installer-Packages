-- Controls removal of MobileCastrate
-- Copyright ©2008, Ripdev
-- Hello Jay! :)

installer.RemovePath("/var/MobileEnhancer/MobileCastrate.men")
installer.RemovePath("/var/Ripdev/libexec/libcastrate.dylib")

return true
